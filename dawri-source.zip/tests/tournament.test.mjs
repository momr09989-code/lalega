import test from 'node:test';
import assert from 'node:assert/strict';
import { generateSchedule, calculateStandings, isValidResult } from '../dist/tournament.js';

const playersFor = (count) => Array.from({ length: count }, (_, i) => ({ id: `p${i}`, name: `Player ${i + 1}` }));

for (const count of Array.from({ length: 31 }, (_, i) => i + 2)) {
  for (const doubleLeg of [false, true]) {
    test(`${count} players, ${doubleLeg ? 'home and away' : 'single leg'}: schedule invariants`, () => {
      const players = playersFor(count);
      const before = structuredClone(players);
      const rounds = generateSchedule(players, doubleLeg);
      const legs = doubleLeg ? 2 : 1;
      const legRounds = count % 2 ? count : count - 1;
      const byes = new Map(players.map(({ id }) => [id, 0]));
      const homes = new Map(players.map(({ id }) => [id, 0]));
      const appearances = new Map(players.map(({ id }) => [id, 0]));
      const pairs = new Map();
      const directions = new Set();
      const ids = new Set();
      assert.equal(rounds.length, legRounds * legs);
      assert.equal(rounds.flatMap((round) => round.matches).length, count * (count - 1) / 2 * legs);
      assert.equal(rounds[0].matches[0].homeId, 'p0');
      assert.equal(rounds[0].matches[0].awayId, 'p1');

      for (const [index, round] of rounds.entries()) {
        assert.equal(round.id, index + 1);
        assert.equal(round.number, index + 1);
        assert.equal(round.leg, index < legRounds ? 1 : 2);
        assert.equal(round.matches.length, Math.floor(count / 2));
        const seen = new Set();
        for (const match of round.matches) {
          assert.notEqual(match.homeId, match.awayId);
          assert.ok(!seen.has(match.homeId) && !seen.has(match.awayId), 'player plays twice in one round');
          assert.ok(appearances.has(match.homeId) && appearances.has(match.awayId));
          seen.add(match.homeId);
          seen.add(match.awayId);
          for (const id of [match.homeId, match.awayId]) appearances.set(id, appearances.get(id) + 1);
          homes.set(match.homeId, homes.get(match.homeId) + 1);
          assert.ok(!ids.has(match.id));
          ids.add(match.id);
          const direction = `${match.homeId}>${match.awayId}`;
          assert.ok(!directions.has(direction), 'repeated directed fixture');
          directions.add(direction);
          const pair = [match.homeId, match.awayId].sort().join(':');
          pairs.set(pair, (pairs.get(pair) || 0) + 1);
        }
        if (count % 2) {
          assert.ok(byes.has(round.byeId));
          assert.ok(!seen.has(round.byeId));
          byes.set(round.byeId, byes.get(round.byeId) + 1);
          seen.add(round.byeId);
        } else assert.equal(round.byeId, null);
        assert.equal(seen.size, count);
      }
      assert.equal(pairs.size, count * (count - 1) / 2);
      assert.ok([...pairs.values()].every((value) => value === legs));
      assert.ok([...byes.values()].every((value) => value === (count % 2 ? legs : 0)));
      assert.ok([...appearances.values()].every((value) => value === (count - 1) * legs));
      for (const player of players) {
        const played = appearances.get(player.id);
        const home = homes.get(player.id);
        assert.ok(Math.abs(home - (played - home)) <= (doubleLeg ? 0 : 1), 'home/away balance');
      }
      if (doubleLeg) {
        for (let index = 0; index < legRounds; index += 1) {
          const first = rounds[index];
          const second = rounds[index + legRounds];
          assert.equal(first.byeId, second.byeId);
          assert.deepEqual(second.matches.map(({ homeId, awayId }) => [homeId, awayId]), first.matches.map(({ homeId, awayId }) => [awayId, homeId]));
        }
      }
      assert.deepEqual(players, before);
      assert.deepEqual(generateSchedule(players, doubleLeg), rounds, 'deterministic output');
    });
  }
}

test('seven-name seeded default produces fourteen rounds and forty-two matches', () => {
  const players = ['Omar', 'Hazem', 'Waled', 'Saif', 'Kareem', 'Mosaab', 'Ziad'].map((name, index) => ({ id: `p${index}`, name }));
  const rounds = generateSchedule(players);
  assert.equal(rounds.length, 14);
  assert.equal(rounds.flatMap((round) => round.matches).length, 42);
  assert.deepEqual(rounds[0].matches[0], { id: 'r1-m1', homeId: 'p0', awayId: 'p1' });
});

test('reject invalid counts and duplicate player IDs', () => {
  for (const players of [[], playersFor(1), playersFor(33), null]) assert.throws(() => generateSchedule(players), RangeError);
  assert.throws(() => generateSchedule([{ id: 'p0' }, { id: 'p0' }]), TypeError);
  assert.throws(() => generateSchedule([{ id: '' }, { id: 'p1' }]), TypeError);
});

test('win, draw, edit and removal recompute standings without accumulated points', () => {
  const players = playersFor(2);
  const rounds = generateSchedule(players);
  const firstId = rounds[0].matches[0].id;
  const secondId = rounds[1].matches[0].id;
  let results = { [firstId]: { home: 3, away: 1 }, [secondId]: { home: 0, away: 0 } };
  let rows = calculateStandings(players, rounds, results);
  assert.deepEqual(rows[0], { id: 'p0', name: 'Player 1', played: 2, won: 1, drawn: 1, lost: 0, gf: 3, ga: 1, gd: 2, points: 4, position: 1 });
  assert.equal(rows[1].points, 1);
  results[firstId] = { home: 0, away: 2 };
  rows = calculateStandings(players, rounds, results);
  assert.equal(rows[0].id, 'p1');
  assert.equal(rows[0].points, 4);
  assert.equal(rows[0].gf, 2);
  delete results[firstId];
  rows = calculateStandings(players, rounds, results);
  assert.ok(rows.every((row) => row.played === 1 && row.points === 1 && row.drawn === 1 && row.won === 0));
  delete results[secondId];
  assert.ok(calculateStandings(players, rounds, results).every((row) => row.played === 0 && row.points === 0));
});

test('incomplete and invalid scores do not count as played matches', () => {
  const players = playersFor(2);
  const rounds = generateSchedule(players, false);
  const matchId = rounds[0].matches[0].id;
  for (const result of [undefined, null, {}, { home: 0 }, { home: '', away: 0 }, { home: '2', away: 1 }, { home: -1, away: 0 }, { home: 100, away: 0 }, { home: 0, away: 100 }, { home: 1.2, away: 0 }, { home: NaN, away: 0 }, { home: Infinity, away: 0 }]) {
    assert.equal(isValidResult(result), false);
    assert.ok(calculateStandings(players, rounds, { [matchId]: result }).every((row) => row.played === 0));
  }
  assert.equal(isValidResult({ home: 0, away: 0 }), true);
  assert.equal(isValidResult({ home: 99, away: 99 }), true);
});

test('ranking uses points, goal difference, goals scored and stable player order', () => {
  const players = playersFor(4);
  const rounds = [{ matches: [
    { id: 'a', homeId: 'p0', awayId: 'p1' },
    { id: 'b', homeId: 'p2', awayId: 'p3' },
  ] }];
  const rows = calculateStandings(players, rounds, { a: { home: 2, away: 0 }, b: { home: 3, away: 1 } });
  assert.deepEqual(rows.map((row) => row.id), ['p2', 'p0', 'p3', 'p1']);
  assert.deepEqual(calculateStandings(players, [], {}).map((row) => row.id), players.map((player) => player.id));
  const gdRows = calculateStandings(players, rounds, { a: { home: 4, away: 0 }, b: { home: 5, away: 2 } });
  assert.equal(gdRows[0].id, 'p0');
});

test('standings preserve inputs and disregard unknown fixture results', () => {
  const players = playersFor(3);
  const rounds = generateSchedule(players);
  const results = { nonsense: { home: 9, away: 0 }, [rounds[0].matches[0].id]: { home: 1, away: 0 } };
  const snapshot = structuredClone({ players, rounds, results });
  const rows = calculateStandings(players, rounds, results);
  assert.equal(rows.reduce((sum, row) => sum + row.played, 0), 2);
  assert.deepEqual({ players, rounds, results }, snapshot);
});
